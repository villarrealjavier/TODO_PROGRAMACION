package main.java.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import main.java.model.Combinacion;

public class MainApp {
	
	public static void main(String[] args) {
		cargarHistorico();
	}
	
	
	private static void numRepetidos(List<Integer> listaCombinacion) {
		Map<Integer,Integer> listaDeNumeros = new HashMap<Integer,Integer>();
		Iterator<Integer> iteradorNumeros = listaCombinacion.iterator();
		for (int i=0; i<=50;i++) {
			listaDeNumeros.put(i, 0);
		}
		
		while (iteradorNumeros.hasNext()) {
			for (Integer i: listaCombinacion) {
				if (listaDeNumeros.containsKey(listaCombinacion.get(i))) {
					listaDeNumeros.replace(i, listaDeNumeros.get(i)+1);
				}
			}
			
		}
				
		
	}

	private static void cargarHistorico() {
		List<Combinacion> historial = new ArrayList<>();
		try {
			
			File file = new File("/home/estudiante/Downloads/Euromillones - 2004 a 2022.csv");
			
			FileReader fr=new FileReader(file);
			BufferedReader br =new BufferedReader(fr);
			br.readLine();
			String linea=br.readLine();
			while ( linea!=null)
			{
			String [] info = linea.split(",");
			Set<Integer> numeros = new HashSet<>();
			numeros.add(Integer.valueOf(info[1]));
			numeros.add(Integer.valueOf(info[2]));
			numeros.add(Integer.valueOf(info[3]));
			numeros.add(Integer.valueOf(info[4]));
			numeros.add(Integer.valueOf(info[5]));

			Set<Integer> estrellas = new HashSet<>();
			estrellas.add(Integer.valueOf(info[7]));
			estrellas.add(Integer.valueOf(info[8]));
			
			Combinacion cb1 = new Combinacion(numeros, estrellas);
			historial.add(cb1);
			linea = br.readLine();
				
			
			}
			System.out.println(historial);
			br.close();
			fr.close();
			
			
		
		}catch(IOException E){
			
		}
	}

}
