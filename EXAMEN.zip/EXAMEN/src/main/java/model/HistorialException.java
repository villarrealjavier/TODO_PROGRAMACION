package main.java.model;

public class HistorialException extends Exception {

	public HistorialException() {
	}

	public HistorialException(String message) {
		super(message);
	}

	public HistorialException(String message, Throwable cause) {
		super(message, cause);
	}


}
