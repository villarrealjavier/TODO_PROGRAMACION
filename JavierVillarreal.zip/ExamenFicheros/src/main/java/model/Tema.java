package main.java.model;

public enum Tema {
	DRAMA,
	INTRIGA,
	COMEDIA,
	CIENCIAFICCION;
	
	
	

}
