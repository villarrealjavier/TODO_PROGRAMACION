package main.java.model;

import java.util.Comparator;

public class ComparadorNumCapitulos implements Comparator<Temporada> {

	

}
