package main.java.model;

public enum Genero {
	HOMBRE(0), MUJER(1);

	int valor;
	
	Genero(int valor){
		this.valor=valor;
	}
}
